import 'dart:convert';
import 'dart:io';

import 'package:app/Widgets/product_card.dart';
import 'package:app/jsonreader/jsonreader.dart';
import 'package:app/models/product_model/item.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

import 'package:flutter/material.dart';

import '../models/product_model/product_model.dart';

class Product extends StatefulWidget {
  Product({Key? key}) : super(key: key);

  @override
  State<Product> createState() => _ProductState();
}

class _ProductState extends State<Product> {
  final List<Item> productlist = [];
  final List imageurl = [
    ("Assets/Images/Apple.jpg"),
    ("Assets/Images/Bananas.jpg"),
    ("Assets/Images/mango.jpg"),
    ("Assets/Images/orange.jpg"),
  ];

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance!.addPostFrameCallback((_) async {
      final products = await readJson();
      productlist.clear();
      setState(() {
        productlist.addAll(products);
      });
    });
    var heightis = MediaQuery.of(context).size.height;
    var widthis = MediaQuery.of(context).size.width;
    return Container(
      width: widthis / 1,
      height: 500,
      child: ListView(
        children: List.generate(productlist.length, (index) {
          final prod = productlist[index];
          final img = imageurl[index];
          if (prod.pId == null) {
            const SizedBox();
          }
          return ProductCard(
            assetImagepath: img,
            p_name: prod.pName ?? "No Name",
            p_cost: prod.pCost ?? 0,
            p_id: prod.pId ?? 0,
            p_availability: prod.pAvailability ?? 0,
            p_category: prod.pCategory ?? "Unavailable",
            p_details: prod.pDetails ?? "Unavailable",
          );
        }),
      ),
    );
  }
}
