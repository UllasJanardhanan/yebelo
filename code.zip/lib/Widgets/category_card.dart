import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CategoryCard extends StatelessWidget {
  final Icon CategoryIcon;
  final String CategoryName;
  const CategoryCard(
      {Key? key, required this.CategoryIcon, required this.CategoryName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(30.0),
      child: Container(
        height: 100,
        width: 150,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(blurRadius: 10.0, color: Colors.blueGrey)]),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CategoryIcon,
            Text(
              CategoryName,
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
