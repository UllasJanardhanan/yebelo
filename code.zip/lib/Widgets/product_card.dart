import 'package:app/Widgets/product.dart';
import 'package:flutter/material.dart';

class ProductCard extends StatelessWidget {
  final String? assetImagepath;
  final String? p_name;
  final int? p_id;
  final int? p_cost;
  final int? p_availability;
  final String? p_details;
  final String? p_category;

  const ProductCard(
      {Key? key,
      this.assetImagepath,
      this.p_name,
      this.p_cost,
      this.p_availability,
      this.p_details,
      this.p_category,
      this.p_id})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    TextEditingController valueInputController = new TextEditingController();

    var widthwindow = MediaQuery.of(context).size.width;
    var heightwindow = MediaQuery.of(context).size.height;
    double id;

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: MaterialButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              title: Center(child: Text(" $p_name")),
              content: Container(
                width: 300,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Quantity :"),
                    Container(
                      height: 30,
                      width: 50,
                      child: TextField(
                        controller: valueInputController,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          // labelText: 'quantity',
                        ),
                      ),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                  },
                  child: Text("Submit"),
                ),
              ],
            ),
          );
        },
        child: Container(
          height: heightwindow / 7,
          width: widthwindow,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [BoxShadow(blurRadius: 10.0, color: Colors.blueGrey)]),
          // color: Colors.white,
          child: Row(
            children: [
              Container(
                height: heightwindow / 7,
                width: 120,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage(assetImagepath!),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 50, right: 50),
                child: Column(
                  children: [
                    Text(
                      "$p_name",
                      style: TextStyle(fontSize: 20),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "Rs :" + "$p_cost" + "/kg",
                        style: TextStyle(fontSize: 20),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "Quantity:" + "$p_availability",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    Text(
                      p_details!,
                      style: TextStyle(fontSize: 15),
                    ),
                    // Text(
                    //   p_category,
                    //   style: TextStyle(fontSize: 15),
                    // ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
