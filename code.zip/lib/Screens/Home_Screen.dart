import 'package:app/models/product_model/item.dart';
import 'package:flutter/material.dart';

import '../Widgets/category.dart';
import '../Widgets/product.dart';

import '../jsonreader/jsonreader.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawer(),
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: const Text("Ecommerce"),
      ),
      body: SafeArea(
          child: ListView(
        children: [
          Padding(
            padding: EdgeInsets.all(25.0),
            child: Categories(),
          ),
          //Products
          Text(
            'Products',
            style: TextStyle(fontSize: 25),
          ),
          TextButton(
              onPressed: () async {
                readJson();
              },
              child: Text('data')),
          Product(),
        ],
      )),
    );
  }
}
