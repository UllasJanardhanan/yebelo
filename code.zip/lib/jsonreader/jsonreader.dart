import 'dart:convert';
import 'dart:io';

import 'package:app/Widgets/product.dart';
import 'package:app/models/product_model/product_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';

import '../models/product_model/item.dart';

Future<List<Item>> readJson() async {
  final String response =
      await rootBundle.loadString('Assets/json/sample.json');
  final data = await json.decode(response);
  final productlist = ProductModel.fromJson(data);

  return productlist.items;
}
