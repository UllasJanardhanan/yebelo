// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Item _$ItemFromJson(Map<String, dynamic> json) => Item(
      pName: json['p_name'] as String?,
      pId: json['p_id'] as int?,
      pCost: json['p_cost'] as int?,
      pAvailability: json['p_availability'] as int?,
      pDetails: json['p_details'] as String?,
      pCategory: json['p_category'] as String?,
    );

Map<String, dynamic> _$ItemToJson(Item instance) => <String, dynamic>{
      'p_name': instance.pName,
      'p_id': instance.pId,
      'p_cost': instance.pCost,
      'p_availability': instance.pAvailability,
      'p_details': instance.pDetails,
      'p_category': instance.pCategory,
    };
