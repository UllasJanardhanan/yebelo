import 'package:json_annotation/json_annotation.dart';

part 'item.g.dart';

@JsonSerializable()
class Item {
  @JsonKey(name: 'p_name')
  String? pName;
  @JsonKey(name: 'p_id')
  int? pId;
  @JsonKey(name: 'p_cost')
  int? pCost;
  @JsonKey(name: 'p_availability')
  int? pAvailability;
  @JsonKey(name: 'p_details')
  String? pDetails;
  @JsonKey(name: 'p_category')
  String? pCategory;

  Item({
    this.pName,
    this.pId,
    this.pCost,
    this.pAvailability,
    this.pDetails,
    this.pCategory,
  });

  factory Item.fromJson(Map<String, dynamic> json) => _$ItemFromJson(json);

  Map<String, dynamic> toJson() => _$ItemToJson(this);
}
